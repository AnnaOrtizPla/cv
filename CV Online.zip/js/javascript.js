 jQuery(document).ready(function($) {
      $('.slider').unslider({
        arrows: false,
        autoplay: true

      });
    });
